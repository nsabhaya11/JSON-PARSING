//
//  ViewController.swift
//  jsonparsing
//
//  Created by MACOS on 11/21/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,URLSessionDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url1 = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.commentary%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=");
        let request = URLRequest(url: url1!);
        
      
        let session = URLSession(configuration: URLSessionConfiguration.default, delegate:self, delegateQueue: nil);
        
        
         let task  = session.dataTask(with: request) { (data, responce, nil) in
            
            do
            {
            
            let test =  try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions()) as Any

               print(test);
                
                var dic = test as! Dictionary<String, Any>;
                
                var dic1 = dic["query"] as! Dictionary<String,Any>;
                
                var dic3  = dic1["results"]  as! Dictionary<String,Any>
                
                var over = dic3["Over"] as? [String:String]
                
                for (index, element) in (over?.enumerated())! {
                   
                    
                    
                    //var v1  = over[index] as Dictionary<String,Any>;
                    
                    
                    
                    
                    
                }

                
                
                
                
                
                
            }
            catch
            {
                
            }

        }
        
        task.resume();
        
        
    
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

